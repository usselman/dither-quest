# Sheol

A private React 19 UI package: thin black rules, square modules, clear grids and orange, blue, yellow, white and black. The first visual study is approved.

- Component lab: https://usselman.github.io/sheol/
- [Installation and API](docs/usage.md)
- [Style guide for agents](docs/style-guide.md)
- [Integration and release maintenance](docs/integration.md)

## Package

Version 0.2.0 exports `Button`, `TextField`, `Panel`, `Badge` and `Dialog` with TypeScript types. Import CSS once from `@sheol/ui/styles.css`. The React entry is safe for server imports; client directives are preserved on interactive components. React and React DOM are peer dependencies (`^19.2.0`). Tested with React 19.2.6 and Next.js 16.3.4.

Use a versioned tarball for personal websites. Keep it in the consumer's `vendor/` directory and commit its dependency and lockfile. Public publishing is not required; `private: true` prevents accidental npm publishing. The optional `@sheol/ui/web-components` entry remains browser-only.

## Install in another website

Sheol 0.2.0 requires Node.js `>=22.13.0`, React `^19.2.0` and React DOM `^19.2.0`. It is an ESM-only package with TypeScript declarations. React 18 is not supported by this release. No public npm publishing is needed.

### 1. Get the package

From your Sheol checkout, generate a versioned tarball:

```sh
# _CODE/sheol/package.json — run from the Sheol checkout
npm ci
npm run check
npm test
mkdir -p artifacts
npm pack --pack-destination artifacts
```

`npm pack` builds the library through its prepack script and creates `artifacts/sheol-ui-0.2.0.tgz`. Alternatively, download the package artifact from a successful [GitHub Actions run](https://github.com/usselman/sheol/actions) and extract the tarball.

### 2. Install in the consumer

Copy the tarball into `your-website/vendor/sheol-ui-0.2.0.tgz`, then run:

```sh
# your-website/package.json — run from the consuming website
npm install ./vendor/sheol-ui-0.2.0.tgz
```

Commit `vendor/sheol-ui-0.2.0.tgz`, `package.json` and your lockfile to the consuming private repository. Its deployment can then install Sheol without access to a second private repository. Use a compatible React/React DOM version in the application; Sheol does not bundle them.

### 3. Import the stylesheet once

For Next.js App Router, import library CSS in the root layout, before your application styles:

```tsx
// app/layout.tsx
import type { ReactNode } from 'react';
import '@sheol/ui/styles.css';
import './globals.css';

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
```

For another React bundler, import `@sheol/ui/styles.css` once in its application entry. Library CSS is scoped to Sheol components and supplies shared tokens; your application owns page typography, padding and layout. Do not import `src/lab.css` or `src/showcase.js`.

## Use the components

Import components from `@sheol/ui`. The following Next.js example uses all five supported exports.

### Server page

`Panel` and `Badge` can render in a server component:

```tsx
// app/settings/page.tsx
import { Badge, Panel } from '@sheol/ui';
import { SettingsForm } from './SettingsForm';

export default function SettingsPage() {
  return (
    <main className="settings-page">
      <h1>Project settings</h1>
      <Badge tone="blue">Personal project</Badge>
      <Panel className="settings-panel">
        <SettingsForm />
      </Panel>
    </main>
  );
}
```

### Interactive form and dialog

Put state and event handlers in a client component. This example validates locally and opens a review dialog; connect persistence to your application's own API.

```tsx
// app/settings/SettingsForm.tsx
'use client';

import { useState, type FormEvent } from 'react';
import { Button, Dialog, TextField } from '@sheol/ui';

/** Demonstrates field validation and a controlled modal without network writes. */
export function SettingsForm() {
  const [name, setName] = useState('Signal study');
  const [error, setError] = useState<string>();
  const [open, setOpen] = useState(false);

  function review(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!name.trim()) {
      setError('Enter a project name.');
      return;
    }
    setError(undefined);
    setOpen(true);
  }

  return (
    <>
      <form className="settings-form" onSubmit={review}>
        <TextField
          label="Project name"
          name="project"
          value={name}
          onChange={event => {
            setName(event.target.value);
            setError(undefined);
          }}
          description="Choose a recognizable name."
          error={error}
        />
        <Button type="submit" tone="orange">Review changes</Button>
      </form>
      <Dialog
        open={open}
        onOpenChange={setOpen}
        title="Review project name"
        description="Check the name before continuing."
        footer={<Button onClick={() => setOpen(false)}>Done</Button>}
      >
        <p>{name.trim()}</p>
      </Dialog>
    </>
  );
}
```

### Application layout styles

Add these rules to your own stylesheet:

```css
/* app/globals.css */
.settings-page {
  display: grid;
  gap: 16px;
  max-width: 640px;
  margin-inline: auto;
  padding: 24px;
  font-family: Arial, Helvetica, sans-serif;
  color: var(--sheol-black);
}

.settings-panel {
  min-width: 0;
  padding: 24px;
}

.settings-form {
  display: grid;
  gap: 16px;
}
```

No `transpilePackages` setting or global client wrapper is required for the compiled package. Interactive components preserve their client directives. See [the complete consumer fixture](examples/next-app/) for loading and save-feedback examples.

### Supported API

| Component | Main props | Usage |
| --- | --- | --- |
| `Button` | `tone`, `size`, `loading`, native button props | Defaults to `type="button"`; set `type="submit"` for forms. Loading disables activation and sets `aria-busy`. |
| `TextField` | Required `label`; `description`, `error`, native input props | Label, help and error relationships are generated. `className` styles the input; `containerClassName` styles its wrapper. |
| `Panel` | Native div props | Rectangular grouping surface; caller supplies padding and layout. |
| `Badge` | `tone`, native span props | Short status or metadata; use `role="status"` for dynamic feedback where appropriate. |
| `Dialog` | Required `open`, `onOpenChange`, `title`; optional `description`, `footer`, `closeLabel` | Controlled native modal with Escape dismissal and browser focus handling. Requires native `dialog.showModal()` support. |

`Tone` is `outline | orange | blue | yellow`; button sizes are `sm | md | lg`. Props types and `Tone` are exported from `@sheol/ui`. Tabs, tables, notifications, switches and sliders in the lab are not supported React exports yet. The optional `@sheol/ui/web-components` entry is browser-only and is unnecessary for React usage.

## Preserve the style in consuming projects

Use shared tokens, 1px black rules, square corners and aligned grids. Keep orange, blue, yellow, white and black as the palette; reserve gradients for occasional graphic accents. Compose existing components before overriding internals. Keep data fetching and business rules in the application.

Add this instruction to each consuming project's root `AGENTS.md`:

```md
<!-- your-website/AGENTS.md -->
Before making UI changes, read:
- node_modules/@sheol/ui/docs/style-guide.md
- node_modules/@sheol/ui/docs/usage.md

Use Sheol's public components and shared tokens. Preserve 1px rules,
square corners, aligned grids, the approved five-color palette and restrained
gradients. Keep accessible labels, visible focus and keyboard behavior.
Keep page layout and domain logic in this application.
```

The consumer's own instructions must point to the guide; a dependency's repository instructions do not automatically govern your application. If guides are copied into your project, record their Sheol version and refresh them with upgrades.

## Upgrade a consumer

Build or obtain a new versioned tarball, copy it into the consumer's `vendor/` directory and install that specific file. Commit the new artifact, dependency and lockfile together. Run the consumer's production build and check forms, dialogs, keyboard focus and narrow layouts before deployment. Consumers adopt updates explicitly; they do not automatically follow Sheol's `main` branch.

## Development

From the checkout (`_CODE/sheol` locally; source files are at repository root):

```sh
# _CODE/sheol/package.json — run from this directory
npm ci
npm run check
npm test
npm run build
npm run verify:consumer
```

- `lib/`: compiled package JavaScript, declarations and library CSS.
- `dist/`: static component lab, including the actual React specimen.
- `artifacts/`: private package tarball and optional test screenshots.
- `examples/next-app/`: real tarball-installed App Router consumer with no source alias.

`npm run test:browser` checks the built consumer using Playwright Chromium. The CI workflow installs Chromium and runs it. Library output, lab output, dependencies and generated tarballs are ignored in Git.

## GitHub Actions and Pages

`.github/workflows/pages.yml` installs locked dependencies, checks and tests the library, builds the lab, verifies the packed Next.js consumer and runs browser interaction checks. It uploads a tarball and screenshots as a build artifact. Pushes to `main` and manual runs deploy `dist/` after verification; pull requests run checks without deployment.

One-time Pages source setup is **Settings → Pages → GitHub Actions**. Private-repository Pages requires a supporting GitHub plan; the review website is ordinarily public even though source is private.

## Architecture

`src/components/` owns React primitives. `src/styles.css` contains tokens and scoped library styles; `src/lab.css` contains lab-only page styles. `src/react-lab.tsx` demonstrates the React API. Native lab examples remain in `src/showcase.js`; do not import that script into a consumer.

Keep application data fetching and business rules outside Sheol. Agent instructions for visual consistency live in `docs/style-guide.md`; consuming projects should reference the packed copy from their own root `AGENTS.md`.
