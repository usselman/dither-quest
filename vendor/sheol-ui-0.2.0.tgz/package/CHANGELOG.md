# Changelog

## 0.2.0

- Add typed React 19 `Button`, `TextField`, `Panel`, `Badge` and `Dialog` exports.
- Separate reusable CSS from lab-only resets and composition styles.
- Preserve per-component client boundaries and keep browser custom elements on an optional entry.
- Include agent-readable style and usage guides in the packed package.
- Add a tarball-installed Next.js App Router fixture and package/browser verification.
- Add a live React specimen to the existing component lab.

## 0.1.0

- Establish the approved thin-line, square-cornered component lab and five-color palette.
- Add GitHub Pages deployment and the initial style/integration documentation.
