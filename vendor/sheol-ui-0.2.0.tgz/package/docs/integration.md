# Private integration status and maintenance

Sheol 0.2.0 implements the first packaging milestone. Read [usage.md](usage.md) for installation and complete Next.js examples, and [style-guide.md](style-guide.md) for the visual contract.

## Implemented

| Area | Status |
| --- | --- |
| Library CSS | Shared tokens and scoped `.sh-*` styles; lab globals are in `src/lab.css` |
| React API | Typed `Button`, `TextField`, `Panel`, `Badge` and `Dialog` |
| Server rendering | Browser globals excluded from the React entry; client directives preserved where needed |
| Package | ESM JavaScript, declarations, stylesheet and agent-readable documentation |
| Distribution | Private versioned tarball; package remains `private: true` |
| Consumer | Next.js 16.3.4 App Router fixture installs the tarball with React 19.2.6 |
| Verification | Package rendering/boundary tests, production consumer build and CI browser interaction checks |
| Design review | Existing Pages lab plus a live React component specimen |

React 19.2 and later within major 19 is the declared peer range. React 18 compatibility is not claimed. The custom-element entry is optional and browser-only. Tabs, tables, notifications and the remaining controls are not React exports yet.

## Private distribution choices

| Method | Good use | Trade-off |
| --- | --- | --- |
| Versioned tarball | Current recommendation for a few personal sites | Each consumer adopts a new artifact explicitly |
| Git dependency pinned to a tag or commit | Environments with private repository access | Installs need dev dependencies for the tested build design; CI must have repository access |
| Workspace dependency | Joint library/application development | Verify the packed artifact too; workspace resolution can hide packaging problems |
| Private registry | Many consumers or frequent releases | Adds authentication and release maintenance |

For the recommended path, copy `artifacts/sheol-ui-0.2.0.tgz` into a consuming private repository's `vendor/` directory, install it and commit the dependency and lockfile. The build needs no access to a second private repository.

Keep `private: true` for tarballs, workspace or Git use. If private registry publishing is adopted later, change that publishing configuration deliberately. The Pages deployment is a review surface, not an npm package host.

## Agent setup

Add an instruction to each consumer's own root `AGENTS.md` directing agents to the installed `node_modules/@sheol/ui/docs/style-guide.md` and `docs/usage.md`. The dependency's own repository instructions do not automatically govern application files. If the guide is vendored, record its Sheol version or commit and refresh it with upgrades.

Require existing public exports and tokens, approved geometry and palette, readable labels, visible focus and keyboard behavior. Keep application layout and product logic in the consumer. Propose additions to Sheol when several screens need the same missing pattern.

## Release process

1. Update components, lab specimens, usage docs and changelog together.
2. Run `npm ci`, `npm run check`, `npm test`, `npm run build` and `npm run verify:consumer`.
3. Run the browser checks locally with Chromium installed, or confirm them in GitHub Actions.
4. Review the lab and representative consumer screens. Do not accept visual changes as a baseline merely to pass tests.
5. Increment the package version and matching fixture tarball dependency together. Regenerate the fixture lockfile.
6. Pack the reviewed source and adopt that artifact in one consumer first. Pin versions and commit lockfiles.

The workflow uploads a private-use tarball and desktop/mobile verification screenshots. It deploys the Pages lab only after package and consumer checks succeed.

## Remaining expansion

Add more typed components when a consuming screen needs them. Add React 18 support only with a tested compatibility implementation. Add a private registry when repeated tarball upgrades become a maintenance burden. Do not change the approved visual language as part of routine distribution work.

## Official references

- npm package specifications: https://docs.npmjs.com/cli/v11/using-npm/package-spec/
- `npm pack`: https://docs.npmjs.com/cli/v11/commands/npm-pack/
- npm package metadata and `private`: https://docs.npmjs.com/cli/configuring-npm/package-json/
- Next.js server/client components: https://nextjs.org/docs/app/getting-started/server-and-client-components
