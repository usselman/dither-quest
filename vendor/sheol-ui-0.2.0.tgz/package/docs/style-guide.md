# Sheol style and usage guide

This is the design contract for agents building with Sheol or extending its components. Read it before changing UI. The approved component lab at https://usselman.github.io/sheol/ is the visual reference; this document explains how to apply its language to other screens.

Status: the first visual study is approved. Sheol 0.2.0 exports typed React `Button`, `TextField`, `Panel`, `Badge` and `Dialog`, plus an isolated stylesheet. Read `usage.md` for the supported API. Other lab examples are not automatically reusable React exports.

## Design intent

Sheol is a minimal neo-brutalist interface system informed by modular audio software, editorial grids, and the supplied Japanese graphic-design reference. Its character comes from precise boundaries, rectangular modules, restrained color blocks and clear information hierarchy.

Use the reference images for their composition and visual structure. Do not reproduce their artwork, logos or text. Do not add decorative Japanese writing.

Preserve these rules:

- Thin black rules, usually 1px.
- Square control and panel corners.
- Shared grids and aligned edges.
- White space around dense groups of useful controls.
- Orange, blue, yellow, white and black as the interface palette.
- Gradients confined to occasional decorative or illustrative panels.
- Clear native interaction, readable text and visible keyboard focus.

Avoid thick cartoon outlines, offset block shadows, rounded pills, glass effects, glowing borders, gratuitous animation, and gradients applied to ordinary controls. Minimalism means removing unnecessary decoration, not removing labels or helpful feedback.

## Color

| Existing token | Value | Typical purpose | Text on a solid fill |
| --- | --- | --- | --- |
| `--sheol-orange` | `#FF6B24` | Main action or attention | Black |
| `--sheol-blue` | `#004CFA` | Selection, active state or secondary action | White |
| `--sheol-yellow` | `#FFE443` | Highlight, pending state or brief notification | Black |
| `--sheol-white` | `#FFFFFF` | Canvas and ordinary surfaces | Black |
| `--sheol-black` | `#111111` | Text, borders and inverse surfaces | White |

The roles are defaults, not a requirement to use all five colors in every view. Begin with white surfaces and black text and rules. Assign one dominant accent to a section; add another only when it communicates a different purpose. A page may intentionally use a large accent panel, but routine controls should not compete for attention.

Use text or a symbol as well as color for statuses. For errors, pair an orange boundary or marker with a clear error message. Do not invent a red or green status palette without an explicit design decision. Check contrast in the actual state: white text on orange or yellow is not the default treatment. A blue focus ring needs a contrasting outer boundary or alternate palette color when it falls on a blue background.

In the current implementation `--sheol-line` is `1px solid var(--sheol-black)`. Prefer semantic tokens for roles when packaging adds them, but do not reference token names that do not yet exist.

## Lines, surfaces and shape

| Element | Default |
| --- | --- |
| Panel and control boundary | 1px black rule |
| Corners | 0px radius |
| Ordinary surface | Solid white |
| Shadow | None |
| Adjacent modules | One visible shared divider |
| Focus indication | Distinct 2px outline with room around it |
| Validation emphasis | May use a 2px orange boundary plus explanatory text |

Avoid accidental doubled borders between joined panels. Put the outside border on a container and internal dividers on its children, or use an equivalent shared-edge composition. A panel can use padding and a background without another enclosing card.

Circles are allowed for diagrams, the signal-field illustration or other meaningful graphic content. They do not imply rounded buttons and pill-shaped badges. The gradient sphere in the lab is an illustration, not a control style.

## Typography

The existing body family is `Arial, Helvetica, sans-serif`; compact metadata uses `monospace`. Keep that baseline until the owner chooses another font system.

- Use plain sans-serif text for titles, content and actions.
- Use monospace for identifiers, values, module labels, versions and short technical metadata.
- Reserve uppercase for short labels and metadata. Use normal sentence case for instructions and paragraphs.
- Create hierarchy with size, spacing and alignment. Avoid adding a new font for every role.
- Large display headings can use tight tracking in hero compositions. Do not apply that tracking to form labels or body text.
- Keep small text readable. The lab's 10–11px specimen annotations are not a default for important product information; prefer 12–14px labels and 14–16px body text when adapting to a real application.
- Keep paragraphs concise without hiding necessary help or error detail.

## Spacing and layout

Use an 8px base unit for new composition spacing: 8, 16, 24, 32, 48 and 64px are useful starting values. Use 4px for fine adjustments. Existing controls have optical padding such as 10px and 19px; preserve approved component geometry rather than mechanically rewriting it to fit the scale.

Align labels, controls and panel boundaries to a coherent grid. Decide which items form a module before drawing borders. Prefer a few clear regions over many small nested cards.

On narrow screens, stack modules and preserve meaningful reading order. Allow controls and labels to wrap without clipping. Use horizontal scrolling only for content that needs it, such as a wide table; do not make the whole page scroll sideways. Dense layouts must still offer comfortable pointer targets and keyboard access.

The large heading, sidebar, five-color strip and graphic sphere belong to the lab composition. They are not required on every consuming website.

## Components and behavior

The library stylesheet provides CSS for `.sh-button`, `.sh-input`, `.sh-select`, `.sh-label`, `.sh-help`, `.sh-panel`, `.sh-badge`, `.sh-switch`, `.sh-range` and `.sh-dialog`. The optional browser-only `@sheol/ui/web-components` entry registers `sheol-panel` and `sheol-badge`. The default package entry provides React components without registering custom elements.

Tabs, notifications and table presentation currently live in the showcase. Their extraction and reusable React behavior APIs remain future work. Do not import `showcase.js` into another application: it queries lab-specific IDs and wires demonstration actions.

| Component | Usage rule |
| --- | --- |
| Button | Give the main action clear priority. Use outline buttons for quieter actions. Use meaningful labels; an arrow is optional. |
| Text field | Keep a persistent label. Connect help and errors with `aria-describedby`. A placeholder does not replace a label. |
| Select | Use for a bounded set of choices; preserve keyboard operation. |
| Badge | Use for short status or metadata. Do not present a noninteractive badge as a button. |
| Panel/card | Group related content. A border must communicate containment or separation. |
| Switch | Use for a boolean setting; state should be apparent from position as well as color. |
| Slider | Display its current value and units; use another input when exact entry is necessary. |
| Tabs | Use to switch related views. Implement tab roles, selected state, panel relationships and arrow-key navigation together. |
| Dialog | Provide a title, explicit close action, Escape behavior, focus containment and focus return. Prefer native `dialog` or a proven accessible primitive. |
| Notification | Announce meaningful results without stealing focus. Persistent problems belong near the affected controls. |
| Table | Use semantic headers, aligned values and thin dividers. Label sample data as sample data. |

Use actual buttons for actions and anchors for navigation. Preserve relevant hover, pressed, focus, disabled, loading and error states. When a disabled style changes colors, ensure it remains clearly disabled even on hover. Keep a pending action from submitting twice.

Motion should be brief and functional. The current controls use approximately 120ms transitions and a 1px pressed movement. Respect reduced motion. Avoid perpetual decorative animation in routine application screens.

## Composition examples

For a settings page, use a plain heading, grouped fields in one or two rectangular sections, a persistent label for each control, and one primary save action. Use thin horizontal dividers to separate settings groups.

For an arcade page, use a grid of aligned game panels, restrained badges for state, a clear play action and a table for the leaderboard. Artwork may provide variety; keep navigation and control geometry consistent.

For a dashboard, organize content by task. Let a table or tightly aligned list carry dense information. Use accent fills to mark selected views or important actions; do not surround every metric with a differently colored card.

## Extension policy

Before adding a variant, try composing existing components and tokens. If the same missing behavior or visual pattern appears in several screens, add it to Sheol and demonstrate its states in the lab.

Keep product data fetching, authentication, ticket balances, game rules and other domain logic in the consuming application. Sheol owns presentation and generic interaction behavior.

Prefer public props and documented tokens over CSS overrides targeting component internals. A one-off wrapper can own page layout; it should not silently restyle buttons or fields. Proposed changes to the palette, typography family, default border weight, corner radius or gradient policy are design changes that require owner review before becoming the baseline.

## Agent workflow

1. Read this guide, `integration.md`, the installed package's documented exports and the consuming project's instructions.
2. Identify the user's task and choose existing components that serve it.
3. Compose with shared tokens. Keep application layout styles separate from the library.
4. Implement all relevant states and keyboard behavior.
5. Check the rendered result at desktop and narrow widths, with long labels and representative content.
6. If extending Sheol, add the component states to the lab and update the usage documentation.
7. Report what changed and how it was verified. If browser verification was unavailable, say so; do not claim visual approval.

For consumer projects, add an instruction to their root `AGENTS.md` directing agents to the installed or vendored copy of this guide. An `AGENTS.md` inside a dependency is not automatically a governing instruction for unrelated application files. When the guide is copied into a consumer, record the Sheol version or commit and refresh it when upgrading.

## Review checklist

- Palette and geometry match the approved language.
- Borders communicate structure; no accidental doubled edges or excessive nested boxes.
- Typography and spacing establish a clear reading order.
- Decorative gradients are rare and contain no essential low-contrast text.
- Important text is readable; statuses do not depend on color alone.
- Inputs have labels, focus is visible, and interaction works by keyboard.
- Narrow layouts and long content do not clip.
- Shared components remain consistent; product logic stays outside the library.

