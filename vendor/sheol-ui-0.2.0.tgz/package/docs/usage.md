# Using Sheol 0.2.0

Sheol is a private, ESM-only React 19 package. The first React exports are `Button`, `TextField`, `Panel`, `Badge` and `Dialog`, plus their TypeScript props and the `Tone` type. React and React DOM are peers; this release is tested with React 19.2.6 and Next.js 16.3.4. React 18 is not supported by this release.

## Create and install a private package

From the Sheol checkout:

```sh
# _CODE/sheol/package.json — commands from this package directory
npm ci
npm run check
npm test
npm run build
mkdir -p artifacts
npm pack --pack-destination artifacts
```

Copy `artifacts/sheol-ui-0.2.0.tgz` into the other website's `vendor/` directory. From that website:

```sh
# your-website/package.json — commands from the consumer project directory
npm install ./vendor/sheol-ui-0.2.0.tgz
```

Commit the tarball, dependency declaration and lockfile in the consuming private repository. This avoids needing a separate private GitHub credential during its deployment build. Do not install from a mutable `main` branch for a release.

## Next.js App Router setup

Import library CSS once in the root layout. It defines Sheol tokens and scoped component styles, without setting body, headings, ordinary buttons or global link styles. App layout, content typography and spacing remain the consumer's responsibility.

```tsx
// app/layout.tsx
import type { ReactNode } from 'react';
import '@sheol/ui/styles.css';
import './globals.css';

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
```

Use server-compatible presentation components from a server page. Put state and event handlers in a client component. The package preserves `use client` on `TextField` and `Dialog`; you do not need `transpilePackages` or a global client wrapper.

```tsx
// app/settings/page.tsx
import { Badge, Panel } from '@sheol/ui';
import { SettingsForm } from './SettingsForm';

export default function SettingsPage() {
  return <main>
    <h1>Project settings</h1>
    <Badge tone="blue">Personal project</Badge>
    <Panel><SettingsForm /></Panel>
  </main>;
}
```

```tsx
// app/settings/SettingsForm.tsx
'use client';

import { useState, type FormEvent } from 'react';
import { Button, Dialog, TextField } from '@sheol/ui';

export function SettingsForm() {
  const [name, setName] = useState('Signal study');
  const [error, setError] = useState<string>();
  const [open, setOpen] = useState(false);

  function review(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!name.trim()) {
      setError('Enter a project name.');
      return;
    }
    setError(undefined);
    setOpen(true);
  }

  return <>
    <form onSubmit={review}>
      <TextField label="Project name" name="project" value={name}
        onChange={event => setName(event.target.value)}
        description="Choose a recognizable name." error={error} />
      <Button type="submit" tone="orange">Review changes</Button>
    </form>
    <Dialog open={open} onOpenChange={setOpen} title="Review project name"
      description="Check the name before continuing."
      footer={<Button onClick={() => setOpen(false)}>Done</Button>}>
      <p>{name}</p>
    </Dialog>
  </>;
}
```

Add your own wrapper classes for padding and layout. `Panel` deliberately does not impose a page-specific spacing scheme. A complete example with loading and save feedback lives in `examples/next-app/`.

## Public component API

| Export | Props beyond native attributes | Behavior |
| --- | --- | --- |
| `Button` | `tone`, `size`, `loading` | Defaults to `type="button"`; loading disables activation and sets `aria-busy` |
| `TextField` | Required `label`; optional `description`, `error`, `containerClassName` | Stable generated ID, associated label, joined descriptions and invalid state |
| `Panel` | Native div attributes | Rectangular surface; caller owns layout and semantic grouping |
| `Badge` | `tone` | Native span for status or metadata; add `role="status"` for dynamic feedback |
| `Dialog` | Required `open`, `onOpenChange`, `title`; optional `description`, `footer`, `closeLabel` | Controlled native modal; Escape/close dismissal reports `false` |

`Tone` is `outline | orange | blue | yellow`. Button `size` is `sm | md | lg`, with a medium 42px baseline. The native `className` and React 19 `ref` are supported on the button, input, panel and badge. `TextField.className` applies to the input; `containerClassName` applies to its wrapper. A supplied field `id` must be unique within the page.

For `Dialog`, the package owns the native ref, open attribute and accessible title/description relationships. It opens through `showModal()` after mount; an initial `open={true}` is safe during server rendering. Caller-controlled `open` is the source of truth. `onCancel` can prevent the default Escape dismissal if a workflow needs it. Put an intentional initial focus target in the contents with `autoFocus` when the default close-button focus is not appropriate. Native `form method="dialog"` dismissal is also supported. The browser must support the native modal dialog API; no legacy polyfill is bundled.

For errors, keep feedback near the field; use a live region in the application when asynchronous announcements are necessary. Set real form submission behavior explicitly. Loading prevents button activation but does not implement request cancellation or a network retry policy.

## Styling and tokens

Import `@sheol/ui/styles.css` before consumer layout styles. Use the tokens listed in `style-guide.md`. The package contains no global reset or body font assignment. Components define their own font and box sizing so unrelated body styles do not determine their control geometry.

Prefer composing public components over overriding their internal descendants. Preserve 1px black rules, square corners and the five-color palette. Focus indicators may use a contrasting white halo to remain visible on blue backgrounds; this is a functional focus treatment, not a decorative panel shadow.

Some native CSS primitives remain available, including select, switch and range classes, but React exports for them are not yet part of the supported API. Tabs, table and notification behavior remain lab examples. Do not import `showcase.js` or lab CSS into a consuming app.

## Optional browser custom elements

`@sheol/ui/web-components` registers `sheol-panel` and `sheol-badge`. This entry is browser-only and is separate from React. Do not import it from server code or during Next.js prerendering. Use it only when an application deliberately chooses custom elements. The React components need neither custom-element registration nor a DOM shim.

## Instructions for other agents

In the consumer project's root `AGENTS.md`, point to these installed files:

- `node_modules/@sheol/ui/docs/style-guide.md`
- `node_modules/@sheol/ui/docs/usage.md`

Require agents to read them before UI changes and to use the installed public exports and shared tokens. Keep domain logic in the consumer. Record the package version when vendoring a copy of the guide. Update that reference when upgrading.

## Verify the packaged consumer

From the Sheol checkout, `npm run verify:consumer` builds and packs the library, inspects the package payload, installs that tarball in `examples/next-app`, runs its production build, and checks the prerendered output. The fixture has no source aliases or transpilation exceptions.

`npm run test:browser` checks the built fixture with Playwright: field validation, modal keyboard behavior, focus return, loading state, CSS isolation, hydration/runtime errors and the 375px layout. Install Playwright Chromium in your development or CI environment first. The GitHub workflow handles this installation and uploads the tarball and verification screenshots as an artifact.
