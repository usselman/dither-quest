import type { ComponentPropsWithRef } from 'react';
import { type Tone } from './shared.js';
export interface ButtonProps extends ComponentPropsWithRef<'button'> {
    /** Approved surface treatment; outline keeps secondary actions quiet. */
    tone?: Tone;
    /** Stable control sizes; medium preserves the approved 42px baseline. */
    size?: 'sm' | 'md' | 'lg';
    /** Disables repeat activation while preserving the visible action label. */
    loading?: boolean;
}
/** Native button with Sheol geometry and safe defaults for use inside forms. */
export declare function Button({ tone, size, loading, disabled, type, className, children, ...props }: ButtonProps): import("react/jsx-runtime").JSX.Element;
