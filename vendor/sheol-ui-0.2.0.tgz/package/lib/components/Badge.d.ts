import type { ComponentPropsWithRef } from 'react';
import { type Tone } from './shared.js';
export interface BadgeProps extends ComponentPropsWithRef<'span'> {
    tone?: Tone;
}
/** Presentational status marker; add role="status" for meaningful dynamic updates. */
export declare function Badge({ tone, className, ...props }: BadgeProps): import("react/jsx-runtime").JSX.Element;
