/** The approved color variants shared by controls and status markers. */
export type Tone = 'outline' | 'orange' | 'blue' | 'yellow';
/** Combines public class hooks without pulling a utility dependency into consumers. */
export declare function classes(...values: Array<string | undefined>): string;
