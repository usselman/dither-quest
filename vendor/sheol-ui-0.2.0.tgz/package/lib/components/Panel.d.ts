import type { ComponentPropsWithRef } from 'react';
export type PanelProps = ComponentPropsWithRef<'div'>;
/** Server-compatible rectangular container. Content and layout belong to the caller. */
export declare function Panel({ className, ...props }: PanelProps): import("react/jsx-runtime").JSX.Element;
