import { type ComponentPropsWithoutRef, type ReactNode } from 'react';
export interface DialogProps extends Omit<ComponentPropsWithoutRef<'dialog'>, 'open' | 'title' | 'aria-labelledby' | 'aria-describedby' | 'ref'> {
    /** Controlled visibility; imperative browser APIs run only after mounting. */
    open: boolean;
    /** Update caller state after Escape, close-button or native form dismissal. */
    onOpenChange: (open: boolean) => void;
    title: ReactNode;
    description?: ReactNode;
    footer?: ReactNode;
    closeLabel?: string;
}
/** Native modal dialog: top layer, focus containment, Escape and focus return. */
export declare function Dialog({ open, onOpenChange, title, description, footer, children, closeLabel, className, onClose, ...props }: DialogProps): import("react/jsx-runtime").JSX.Element;
