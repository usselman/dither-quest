import { type ComponentPropsWithRef, type ReactNode } from 'react';
export interface TextFieldProps extends Omit<ComponentPropsWithRef<'input'>, 'children'> {
    /** Persistent visible label; placeholders never replace it. */
    label: ReactNode;
    description?: ReactNode;
    /** A visible error also marks the input invalid and joins its accessible description. */
    error?: ReactNode;
    containerClassName?: string;
}
/** Labeled native field with hydration-stable IDs and connected help/error content. */
export declare function TextField({ label, description, error, containerClassName, className, id, 'aria-describedby': externalDescription, 'aria-invalid': invalid, ...props }: TextFieldProps): import("react/jsx-runtime").JSX.Element;
